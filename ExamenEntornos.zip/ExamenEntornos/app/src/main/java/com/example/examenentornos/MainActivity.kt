package com.example.examenentornos

import android.content.Intent
import android.graphics.Color
import android.graphics.Color.green
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var button = findViewById<Button>(R.id.button)

        var button2 = findViewById<Button>(R.id.button2)

        var button3 = findViewById<Button>(R.id.button3)

        var textView = findViewById<TextView>(R.id.textView)

        button.setOnClickListener{
            startActivity(Intent(this,MainActivity2::class.java))
        }
        button2.setOnClickListener{
            startActivity(Intent(this,MainActivity3::class.java))
        }
        button3.setOnClickListener {
            textView.setText("EXITO_LABORAL")
            textView.setBackgroundColor(Color.parseColor("#adff2f"))
            textView.setTextColor(Color.parseColor("#ffffff"))
        }



    }
}